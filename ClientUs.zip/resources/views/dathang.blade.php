@extends('welcome')

@section('content')
<div class="sw-dathang">
	<div class="me-dh">
	<div>Hình Ảnh</div>
	<div>Tên sản phẩm</div>
	<div>Giá Sản phẩm</div>
	<div>Số Lượng Kho</div>
	<div>Số lượng</div>
	<div>Xóa</div>
</div>
	<div class="jax">
	</div>

 	
@endsection
