

<?php $__env->startSection('content'); ?>
<div class="sw-dathang">
	<div class="me-dh">
	<div>Hình Ảnh</div>
	<div>Tên sản phẩm</div>
	<div>Giá Sản phẩm</div>
	<div>Số Lượng Kho</div>
	<div>Số lượng</div>
	<div>Xóa</div>
</div>
	<div class="jax">
	</div>

 	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ClientUs\resources\views/dathang.blade.php ENDPATH**/ ?>