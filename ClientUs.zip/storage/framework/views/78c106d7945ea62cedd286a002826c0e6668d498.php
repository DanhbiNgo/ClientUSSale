

<?php $__env->startSection('donhang'); ?>


<div class="diachi">
	<div class="diachi-top">
	<div>Địa Chỉ Của Tôi</div>
	<div ><button onclick="Hidediachi()">+Thêm Địa Chỉ Mới</button></div>
	</div>
	<div class="diachi2">
	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $__currentLoopData = $diachi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($dc->user_ma == $us->id): ?>
			<div class="diachi3">
			<div><span>Họ và Tên</span><?php echo e($dc->name); ?></div>
			<div><span>Số Điện Thoại</span><?php echo e($us->phone); ?></div>
			<div><span>Địa Chỉ</span><?php echo e($dc->address); ?></div>
			<div class="xoadc"><a href="">Xóa</a></div>
			</div>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>


<div class="cre-diachi">
	<div class="diachi1">
		<form action="<?php echo e(url('/address')); ?>" method="POST"> 
			<?php echo csrf_field(); ?>
		<div><h3>Địa Chỉ Mới</h3></div>
		<div><input type="text" value="" placeholder="Họ và Tên" name="tenuser"></div>
		<div><input type="text" placeholder="Số điện thoại" name="phone"></div>
		<div><select name="tp">
			<option>TP.Hồ Chí Minh</option>
			<option>Cần Thơ</option>
			<option>Vĩnh Long</option>
			<option>Cà Mau</option>
			<option>Tiền Giang</option>
			<option>Bạc Liêu</option>
			<option>Sóc Trăng</option>
			<option>An Giang</option>
			<option>Bến Tre</option>
			<option>Long An</option>
		</select></div>
		<div><input type="text" placeholder="Địa Chỉ Cụ Thể" name="address"></div>

		<div>
			<input type="submit" name="Hoàn Thành">
		</div>
		<div>
			<a href="javascript::" onclick="Hide()">Trở Lại</a>
		</div>
	</form>
	</div>
</div>
<script type="text/javascript">
	function Hidediachi(){
		document.getElementsByClassName('cre-diachi')[0].style.display="block";
	}
	function Hide(){
		document.getElementsByClassName('cre-diachi')[0].style.display="none";
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('thongtinkh', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ClientUs\resources\views/diachi.blade.php ENDPATH**/ ?>