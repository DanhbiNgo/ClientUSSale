<?php $__currentLoopData = $giohang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($gh->id_user == Auth::user()->id): ?>
<div class="alldathang">
			<?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($sp->sp_ma == $gh->sp_ma): ?>
			<?php $__currentLoopData = $hinhanh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($sp->sp_ma == $ha->sp_ma): ?>
			<div><img src="http://localhost:8000/Server/public/<?php echo e($ha->hinhanh); ?>" width="100px" height="100px"></div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div><?php echo e($sp->sp_ten); ?>

			</div>
			<div id="giadh" class="giadh"><?php echo e($sp->sp_giaban*$gh->soluong); ?></div>
			<div class="sp-soluong" id="sl"><?php echo e($sp->sp_soluong); ?></div>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="input-group">
  			<input type="button" value="-" class="button-minus1" data-field="quantity" id="bt-" onclick="clicksub(<?php echo e($gh->sp_ma); ?>)">
 			 <input type="number" step="1" max="" value="<?php echo e($gh->soluong); ?>" name="quantity" class="input-max" id="number" onkeyup="change(<?php echo e($gh->sp_ma); ?>,this.value)">
  				<input type="button" value="+" class="button-plus1" data-field="quantity" id="bt+" onclick="clickadd(<?php echo e($gh->sp_ma); ?>)">
			</div>
			<div><span class="deletedh" onclick="deletedh(<?php echo e($gh->gh_ma); ?>)">&times;</span></div>

		</div>
		<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="muahang">
	<div class="chosedc">
		<form action="<?php echo e(url('/dathang')); ?>" method="POST">
			<?php echo csrf_field(); ?>
	<div class="adres">
		<div>Chọn Địa Chỉ:</div>
	<div><select name="diachisl">
	<?php $__currentLoopData = $diachi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 	<option><?php echo e($dc->address); ?></option>
 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 </select>
	</div>
	<a href="javascript::" style="text-decoration: none;
    color: wheat;
    background: black;
    cursor: pointer;
    border: 1px solid;
    border-radius: 5px;" onclick="Hidediachi()">Thêm mới</a>
	 </div>
	 <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 	<?php if($us->id== Auth::id()): ?>
	 	<div class="sdt">
	 		<div>Số Điện Thoại:</div>
	 <div><input type="text" name="phone" value="<?php echo e($us->phone); ?>"></div>
	</div>
	 	<?php endif; ?>
	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="buy">
	<div>Tổng Tiền:</div>
	<div class="giadh"><?php echo e($total); ?></div>
 		<div><button>Mua Ngay</button></div>
 	</form>
 	</div>

 	</div>
 <div class="cre-diachi" style="top:20%">
	<div class="diachi1">
		<form action="<?php echo e(url('/address')); ?>" method="POST"> 
			<?php echo csrf_field(); ?>
		<div><h3>Địa Chỉ Mới</h3></div>
		<div><input type="text" value="" placeholder="Họ và Tên" name="tenuser"></div>
		<div><input type="text" placeholder="Số điện thoại" name="phone"></div>
		<div><select name="tp">
			<option>TP.Hồ Chí Minh</option>
			<option>Cần Thơ</option>
			<option>Vĩnh Long</option>
			<option>Cà Mau</option>
			<option>Tiền Giang</option>
			<option>Bạc Liêu</option>
			<option>Sóc Trăng</option>
			<option>An Giang</option>
			<option>Bến Tre</option>
			<option>Long An</option>
		</select></div>
		<div><input type="text" placeholder="Địa Chỉ Cụ Thể" name="address"></div>

		<div>
			<input type="submit" name="Hoàn Thành">
		</div>
		<div>
			<a href="javascript::" onclick="Hide()">Trở Lại</a>
		</div>
	</form>
	</div>
</div>
 <script>
	var gia = document.getElementsByClassName("giadh");
	for(var i = 0 ;i < gia.length; i++){
		var number = gia[i].innerHTML;
 var ngia   = Number(number).toFixed(3).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
var sbgia = ngia.substring(0,ngia.indexOf('.'));
	gia[i].innerHTML =sbgia+" VNĐ";
}
function Hidediachi(){
		document.getElementsByClassName('cre-diachi')[0].style.display="block";
	}
	function Hide(){
		document.getElementsByClassName('cre-diachi')[0].style.display="none";
	}
</script>
<script type="text/javascript" src="js/ctsp.js"></script><?php /**PATH C:\xampp\htdocs\ClientUs\resources\views/showdh.blade.php ENDPATH**/ ?>