<?php $__currentLoopData = $spsl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $__currentLoopData = $hinhanh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($sp->sp_ma == $ha->sp_ma): ?>
	<div class='e-search'>
		<a href="<?php echo e(url('/ctsp',$sp->sp_ma)); ?>">
			<div><img src="https://localhost/Server/public/<?php echo e($ha->hinhanh); ?>" width="200px" height="200px"></div>
			<div><?php echo e($sp->sp_ten); ?></div>
		</a>
	</div>
	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ClientUs\resources\views/shsearch.blade.php ENDPATH**/ ?>