

<?php $__env->startSection('content'); ?>
<div class="re-home">
    <a href="<?php echo e(url('/home')); ?>">Home</a><span></span>
    <a><?php echo e($selectloai[0]->l_ten); ?></a>
</div>
<div class="stick-filter">
    <?php $__currentLoopData = $select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanpham): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product">
        <?php $__currentLoopData = $hinhanhsanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hinhanhsp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($hinhanhsp->sp_ma == $sanpham->sp_ma): ?>
        <div class="img"><img src="http://localhost:8000/Server/public/<?php echo e($hinhanhsp->hinhanh); ?>" width='250' height="250"></div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="content"><?php echo e($sanpham->sp_ten); ?></div>
        <div class="giasp" style="text-align: center; height: 30px;"><?php echo e($sanpham->sp_giaban); ?></div>
        <a href="<?php echo e(url('/ctsp',$sanpham->sp_ma)); ?>"><div class="ctsp">Chi tiết</div></a>
        <a href="javascript::" onclick="addcart(<?php echo e($sanpham->sp_ma); ?>)"><div class="ctsp">Thêm Giỏ</div></a>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
    <div><?php echo e($select->links("pagination::bootstrap-4")); ?></div>

    <script>
    var gia = document.getElementsByClassName("giasp");
    for(var i = 0 ;i < gia.length; i++){
        var number = gia[i].innerHTML;
 var ngia   = Number(number).toFixed(3).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
var sbgia = ngia.substring(0,ngia.indexOf('.'));
    gia[i].innerHTML =sbgia+" VNĐ";
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ClientUs\resources\views/sanpham.blade.php ENDPATH**/ ?>