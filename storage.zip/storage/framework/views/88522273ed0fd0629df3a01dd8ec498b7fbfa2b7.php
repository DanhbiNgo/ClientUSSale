<div style="float:left;">
		<div class="img-ad"><img src="./images/ASSET-USER-ADMIN.png" width="40px" height="40px"></div>
		<div class="adchat" >
			Bạn Cần Giúp Gì?
		</div>
		</div>
		<div style="clear:left;"></div>
<?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($mes->user_ma == Auth::id() && $mes->ad_ma == null): ?>
		<div  style="float:right;">	
			<div class="userchat"><?php echo e($mes->mes); ?>

			<span></span></div>
			<div style="font-size:10px;"> <?php echo e($mes->created_at); ?></div>
		</div>

	<?php endif; ?>
			<div style="clear:right"></div>
		<?php if($mes->ad_ma == 1 && $mes->user_ma == Auth::id()): ?>
		<div style="float:left;">
		<div class="img-ad"><img src="./images/ASSET-USER-ADMIN.png" width="40px" height="40px"></div>
		<div class="adchat" >
			<?php echo e($mes->mes); ?>

		</div>
		<div style="font-size:10px;"> <?php echo e($mes->created_at); ?></div>
		</div>
		<div style="clear:left;"></div>
		<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ClientUs\resources\views/chat.blade.php ENDPATH**/ ?>